
##Highlight the code (line 4 through 10) below and run it!

library(tidyverse)
Biodiversity_Index_spelling <- read_csv("Biodiversity_Index.csv")

#Fix spelling errors in dataset, so that it is compatible with the rest of the code
Biodiversity_Index <- Biodiversity_Index_spelling |> 
  mutate(Biome=recode(Biome, 'Temperate Conferous Forest' = 'Temperate Coniferous Forest', 
                     'Tropical and Subtropical moist broadleaf forest' = 'Tropical Forest'), 
         Taxa=recode(Taxa, 'Terrestial Invertebrate'='Terrestrial Invertebrates', 
                     'Terrestial Plant' = 'Terrestrial Plants',
                     'Terrestial Plants' = 'Terrestrial Plants'))

########### GROUP 1 #############

# Number of Species Temperate Plants

Biodiversity_Index|>
  filter(Biome=="Temperate Coniferous Forest", Taxa=="Terrestrial Plants")|>
ggplot(aes(x=YEAR,y= numspecies)) + geom_col(fill= "darkseagreen", color= "grey37")+
  labs(title = "Number of Terrestrial Plant Species", 
       subtitle = "In Temperate Coniferous Forest", 
       x= "Year", y= "Number of species") + theme_linedraw() + 
  theme(plot.title = element_text( hjust= .5, face = "bold"), plot.subtitle = element_text(hjust = .5)) 

# Number of Species Temperate Invertebrates

Biodiversity_Index|>
  filter(Biome=="Temperate Coniferous Forest", Taxa=="Terrestrial Invertebrates")|>
  ggplot(aes(x=YEAR, y= numspecies)) +geom_col(fill= "salmon3", color= "grey37") +
  labs(title = "Number of Terrestrial Invertebrate Species", 
       subtitle = "In Temperate Coniferous Forest ",
       x= "Year", y= "Number of Species") +theme_linedraw() +
  theme(plot.title = element_text( hjust= .5, face = "bold"), plot.subtitle = element_text(hjust = .5)) 


############ GROUP 2 ###############

#Diversity Index Temperate Plants

Biodiversity_Index|>
  filter(Biome=="Temperate Coniferous Forest", Taxa== "Terrestrial Plants")|>
  ggplot(aes(x= YEAR, y= index)) + geom_col(fill= "darkseagreen", color="grey37") + 
  labs(title = "Biodiversity Index of Terrestrial Plants", 
       subtitle = "In Temperate Coniferous Forest",
       x= "Year", y= "Biodiversity Index") +
  theme_linedraw()+
  theme(plot.title = element_text( hjust= .5, face = "bold"), plot.subtitle = element_text(hjust = .5)) 

#Diversity Index Temperate Invertebrates

Biodiversity_Index|>
  filter(Biome=="Temperate Coniferous Forest", Taxa=="Terrestrial Invertebrates")|>
  ggplot(aes(x=YEAR, y= index)) +geom_col(fill= "salmon3", color= "grey37") +
  labs(title = "Biodiversity Index of Terrestrial Invertebrates", 
       subtitle = "In Temperate Coniferous Forest", 
       x= "Year", y= "Biodiversity Index") + theme_linedraw() +
  theme(plot.title = element_text( hjust= .5, face = "bold"), plot.subtitle = element_text(hjust = .5))

############ GROUP 3 ###############

#Number of Species Tropical Plants

Biodiversity_Index|>
  filter(Biome=="Tropical Forest", Taxa=="Terrestrial Plants")|>
  ggplot(aes(x=YEAR,y= numspecies)) +geom_col(fill= "seagreen", color= "grey37")+
  labs(title = "Number of Terrestrial Plant Species",
       subtitle = "In Tropical Forest", 
       x= "Year", y= "Number of species") + theme_linedraw() + 
  theme(plot.title = element_text( hjust= .5, face = "bold"), plot.subtitle = element_text(hjust = .5))

#Number of Species Tropical Invertebrates

Biodiversity_Index|>
  filter(Biome=="Tropical Forest", Taxa=="Terrestrial Invertebrates")|>
  ggplot(aes(x=YEAR,y= numspecies)) +geom_col(fill= "brown", color= "grey37")+
  labs(title = "Number of Terrestrial Invertebrate Species",
       subtitle = "In Tropical Forest", 
       x= "Year", y= "Number of species") + theme_linedraw() + 
  theme(plot.title = element_text( hjust= .5, face = "bold"), plot.subtitle = element_text(hjust = .5)) 

############ GROUP 4 ###############

# Diversity Index Tropical Plants

Biodiversity_Index|>
  filter(Biome=="Tropical Forest", Taxa== "Terrestrial Plants")|>
  ggplot(aes(x= YEAR, y= index)) + geom_col(fill= "seagreen", color="grey37") + 
  labs(title = "Biodiversity Index of Terrestrial Plants", 
       subtitle = "In Tropical Forest", 
       x= "Year", y= "Biodiversity Index" ) +
  theme_linedraw()+
  theme(plot.title = element_text( hjust= .5, face = "bold"), plot.subtitle = element_text(hjust = .5))

# Diversity Index Tropical Invertebrates

Biodiversity_Index|>
  filter(Biome=="Tropical Forest", Taxa=="Terrestrial Invertebrates")|>
  ggplot(aes(x= YEAR, y= index)) + geom_col(fill= "brown", color="grey37") + 
  labs(title = "Biodiversity Index of Terrestrial Invertebrates", 
       subtitle = "In Tropical Forest", 
       x= "Year", y= "Biodiversity Index" ) +
  theme_linedraw()+
  theme(plot.title = element_text( hjust= .5, face = "bold"), plot.subtitle = element_text(hjust = .5))
