library(tidyverse)
library(lubridate)

Sea_Level_1970<- read_csv('Data/Sea_Level_1970.csv')
Sea_Level<- Sea_Level_1970 %>% 
  unite(col = "Date", Month, Year, sep = "-") %>% 
  mutate(Date = my(Date)) 
  
#view(Sea_Level)

#all location line graph
ggplot(Sea_Level, aes(x = Date, y = Linear_Trend, color = Location)) +
  geom_line() +
  scale_color_manual(values = c(
    "Charleston SC" = "salmon",
    "Garibaldi" = "gold",
    "Los Angeles" = "chartreuse",
    "Majuro C, Marshall Islands" = "violet",
    "Portland ME" = "cyan2",
    "San Francisco" = "blue",
    "Sewells Point VA" = "blueviolet"))  +
  theme_light()+
  labs(title="Sea Level Change from 1970-2023 \nCompared to Marshall Islands",x="Year",y="Change in Meters")
                            
                          
                        
#no_marshall <- Sea_Level %>% 
#  filter(Location != "Majuro C, Marshall Islands")

No_Garibaldi<- read_csv("Data/No_Garibaldi.csv")

Trend<-No_Garibaldi %>% 
filter(Year>1969, Year<2023 , Location != "Majuro C, Marshall Islands") %>% 
  group_by(Location,Year) %>% 
  summarize(Avg=mean(Monthly_MSL))

#no marshall line graph
ggplot(Trend, aes(x = Year, y = Avg, color = Location)) +
  #geom_line()+
  geom_smooth()+
  ##For a more detailed line graph, use geom_line instead of geom_smooth

  scale_color_manual(values = c(
    "Charleston SC" = "salmon",
    "Garibaldi" = "gold",
    "Los Angeles" = "chartreuse",
    "Portland ME" = "cyan2",
    "San Francisco" = "blue",
    "Sewells Point VA" = "blueviolet"))  +
  theme_light()+
  labs(title="Average Change in Sea Level from 1970-2022",x="Year",y="Change in Meters")



only_marshall <- Sea_Level %>% 
  filter(Location == "Majuro C, Marshall Islands")

#only marshall data
ggplot(only_marshall, aes(x = Date, y = Linear_Trend, color = Location)) +
  geom_line()

##Questions##
#How do you assign a value to a color line so that every graph is consistent?
#There is data up until 2023 except for Marshall Islands, which only has data up 
  #until 2018. Should we exclude any data above 2018, find new data for Marshall 
  #Islands, or use the data as it is, with Marshall Islands only going to 2018 
  #and all other locations going up to 2023?


