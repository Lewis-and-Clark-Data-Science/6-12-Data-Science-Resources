
### NOTE: This code is integrated into "Total Sea Level Change Since 1970.Rmd" 
### This file does not need to be run, but is kept because it includes a variety of ways of executing code
### that differ from the .Rmd file but produce the same results 



library(tidyverse)
No_Garibaldi <- read_csv('Data/No_Garibaldi.csv')
Astoria<-No_Garibaldi|>filter(Location=="Astoria")

Astoria_Avg<-Astoria%>%
  group_by(Year, Location)%>%
  summarize(Avg=mean(Monthly_MSL)) %>% 
  filter(Year>1969&Year<2022)

#Scatter Plot for Astoria
ggplot(Astoria_Avg,aes(x=Year,y=Avg))+
  geom_point(color="salmon")+
  labs(title="Average Change In Sea Level per Meter in Astoria",y="Average Change in Sea Level (m)")+
  theme_light()+geom_smooth(method="lm",color="black",se=FALSE)

Avg<-No_Garibaldi%>%
  group_by(Year,Location)%>%
  summarize(Avg=mean(Monthly_MSL))%>%
  filter(Year>1969&Year<2023)


##Ethan code
install.packages('plyr')
#Note: I am NOT including the library command because 'plyr' messes with group_by and summarize, so we don't want to call it up overall. 
      #Instead we'll call it up for specific commands. See two lines below this one.
bin_data<-Avg %>% 
  mutate(bin = plyr::round_any(Year, 10)) 
  

#buggy code
#Avg %>% mutate(bin = cut_width(Year, width=10, boundary=0, closed="left")) 

Decades<-bin_data%>%
  group_by(bin,Location)%>%
  summarize(Avg=mean(Avg))%>%
  filter(Location!="Majuro C, Marshall Islands")

Ranges<-Avg%>%
  group_by(Location) %>% 
  filter(Year==1970|Year==2022) %>% 
  summarise(Range = diff(range(Avg))) %>% 
  filter(Location!="Majuro C, Marshall Islands")

Marshall_range <- Avg %>% 
  group_by(Location) %>% 
  filter(Location == "Majuro C, Marshall Islands",
         Year == 1970 | Year == 2018) %>% 
  summarise(Range = diff(range(Avg)))

Ranges_all <- bind_rows(Ranges, Marshall_range) %>% 
  mutate(Region = if_else(Location == "Majuro C, Marshall Islands", "Oceania",
                          if_else(Location %in% c("Astoria", "Los Angeles", "San Francisco"), "West Coast", false = "East Coast"))) %>% 
  mutate(Region = factor(Region, levels = c("West Coast", "East Coast", "Oceania")))

ggplot(Ranges_all, aes(x = reorder(Location, Range), y = Range, fill=Location)) +
  geom_col(position="dodge")+
  theme_light()+
  labs(x="Location", y="Average Sea Level Change (m)",
       title="Average Sea Level Change in Meters \nfrom 1970-2022")+
  facet_grid(. ~ Region, drop = TRUE, scales = "free_x", space = "free") +
  scale_fill_manual(values=c("Astoria"="salmon", "Charleston SC"="gold", 
                             "Los Angeles"="chartreuse","Portland ME"="cyan2",
                             "San Francisco"="blue","Sewells Point VA"="blueviolet",
                             "Majuro C, Marshall Islands" = "forestgreen")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
    #This theme angles the x axis labels so they are easier to read

Total_avg<-Decades%>%group_by(Location)%>%summarize(Avg=mean(Avg))




