library(tidyverse)
Sea_Level_1970<- read_csv('Data/Sea_Level_1970.csv')

Sea_Avg2<-Sea_Level_1970%>%
  filter(Year==1998|Year==2008|Year==2018|Year==2023)%>%
  mutate(Year_Cr=as.character(Year))%>%
  select(Year_Cr,Linear_Trend,Location)%>%
  group_by(Year_Cr,Location)%>%
  summarize(Avg=mean(Linear_Trend))

Sea_Avg2$Location <- factor(Sea_Avg2$Location, levels = c("Charleston SC","Garibaldi",
                                                          "Los Angeles", "Portland ME",
                                                          "San Francisco","Sewells Point VA",
                                                          "Majuro C, Marshall Islands"))


portlands<-Sea_Avg2|>filter(Location=="Garibaldi"|Location=="Portland ME")

#Comparison of Garibaldi and Portland ME
ggplot(portlands, aes(x = Year_Cr, y = Avg, fill=Location)) +
  geom_col(position="dodge")+theme_light()+
  labs(x="Year", y="Average Sea Level Change (m)",title="Average Sea Level Change
       \nIn Garibaldi and Portland, ME")+
  scale_fill_manual(values=c("Garibaldi"="gold","Portland ME"="cyan2"))

SF_VA<-Sea_Avg2|>filter(Location=="San Francisco"|Location=="Sewells Point VA")

#Comparison of SF and VA
ggplot(SF_VA, aes(x = Year_Cr, y = Avg, fill=Location)) +
  geom_col(position="dodge")+theme_light()+
  labs(x="Year", y="Average Sea Level Change (m)",title="Average Sea Level Change
       \nIn San Francisco and Sewells Point, VA")+
  scale_fill_manual(values=c("San Francisco"="blue","Sewells Point VA"="blueviolet"))

LA_SC<-Sea_Avg2|>filter(Location=="Los Angeles"|Location=="Charleston SC")

#Comparison of LA and SC
ggplot(LA_SC, aes(x = Year_Cr, y = Avg, fill=Location)) +
  geom_col(position="dodge")+theme_light()+
  labs(x="Year", y="Average Sea Level Change (m)",title="Average Sea Level Change
       \nIn Los Angeles and Charleston, SC")+
  scale_fill_manual(values=c("Los Angeles"="chartreuse","Charleston SC"="salmon"))

