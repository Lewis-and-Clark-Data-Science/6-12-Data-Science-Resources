library(tidyverse)
Sea_Level_1970<- read_csv('Data/Sea_Level_1970.csv')

Sea_Avg2<-Sea_Level_1970%>%
  filter(Year==1998|Year==2008|Year==2018|Year==2023)%>%
  mutate(Year_Cr=as.character(Year))%>%
  select(Year_Cr,Linear_Trend,Location)%>%
  group_by(Year_Cr,Location)%>%
  summarize(Avg=mean(Linear_Trend))

Sea_Avg2$Location <- factor(Sea_Avg2$Location, levels = c("Charleston SC","Garibaldi",
                                                          "Los Angeles", "Portland ME",
                                                          "San Francisco","Sewells Point VA",
                                                          "Majuro C, Marshall Islands"))

#Graph All
ggplot(Sea_Avg2, aes(x = Year_Cr, y = Avg, fill=Location)) +
  geom_col( position="dodge")+theme_light()+
  labs(x="Year", y="Average Sea Level Change (m)",
  title="Average Sea Level Change in Meters \nfrom 1970-2023 Compared to \nMarshall Islands")+
  scale_fill_manual(values=c("Charleston SC"="salmon", "Garibaldi"="gold", 
                            "Los Angeles"="chartreuse","Portland ME"="cyan2",
                            "San Francisco"="blue","Sewells Point VA"="blueviolet",
                            "Majuro C, Marshall Islands"="violet"))


no_marshall <- Sea_Avg2 %>% 
  filter(Location != "Majuro C, Marshall Islands")

#Graph No Marshall
ggplot(no_marshall, aes(x = Year_Cr, y = Avg, fill=Location)) +
  geom_col(position="dodge")+theme_light()+
  labs(x="Year", y="Average Sea Level Change (m)",
       title="Average Sea Level Change in Meters \nfrom 1970-2023")+
  scale_fill_manual(values=c("Charleston SC"="salmon", "Garibaldi"="gold", 
                             "Los Angeles"="chartreuse","Portland ME"="cyan2",
                             "San Francisco"="blue","Sewells Point VA"="blueviolet"))
  



