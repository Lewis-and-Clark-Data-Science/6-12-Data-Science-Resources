### This code will create a graph of Chinook crossing the Bonneville Dam from 1939-2023


library(tidyverse)
Bon_chinook <- read_csv("Data/Bonneville_Dam_1939_2023_Chinook_CSV.csv")

names(Bon_chinook) <- Bon_chinook[1,]
Bon_chinook <- Bon_chinook[-1,]
  #Move first row to header and delete the row
Bon_chinook_t <- t(Bon_chinook)
  #Transpose
colnames(Bon_chinook_t) <- Bon_chinook_t[1,]
Bon_chinook_t <- Bon_chinook_t[-1,]
  #Move first row to header and delete the row

Bon_chinook_t <- as.data.frame(Bon_chinook_t)

Bon_chinook_t <- Bon_chinook_t %>% replace(is.na(.), 0)
  #make NA into 0 values
Bon_chinook_t <- Bon_chinook_t %>% select(1:365)
  #Delete extra info we don't want 
str(Bon_chinook_t)
  #Check what kind of data we have... Oh no! It's character data not numeric data
Bon_chinook_t <-Bon_chinook_t %>% mutate_all(function(x) as.numeric(as.character(x)))
  #Change character to numeric data
Bon_chinook_sum <-  Bon_chinook_t %>% mutate(sum_of_rows = rowSums(Bon_chinook_t))
  #Add a new column summing the rows

Bon_chinook_sum$year <- 2023:1938
  #Add a year column with just the year

options(scipen = 999) 
  #Don't use standard notation
Bon_chinook_sum <- Bon_chinook_sum %>% mutate(sum_of_rows_100 = (sum_of_rows/1000))

y_max <- max(Bon_chinook_sum$sum_of_rows_100)

ggplot(data = Bon_chinook_sum, aes(x = year, y = sum_of_rows_100)) +
  geom_point() +
  #geom_line(color = "salmon") +
  #geom_smooth(method="lm") +
  labs(title = "Number of Chinook Crossings per Year at Bonneville Dam from 1938-2023",
       x = "Year",
       y = "Number of Chinook Crossing (in 1000s)") + 
      scale_x_continuous(breaks = seq(1938,2023,5)) +
      #scale_x_continuous(breaks = scales::pretty_breaks(n=10)) + 
      scale_y_continuous(breaks = seq(0,y_max,100))
ggsave(filename="Chinook_Bonneville_Graph_noline.jpg",  plot=last_plot(),path="output", width=2500, height=1200, units="px")

#You can comment out the `geom_line()` command to include a connecting line or not
