### This code will create a graph of Chinook crossing the Dalles from 1957-2023


library(tidyverse)
Dalles_chinook <- read_csv("Data/Chinook_Dalles_1957_2023.csv")

names(Dalles_chinook) <- Dalles_chinook[1,]
Dalles_chinook <- Dalles_chinook[-1,]
#Move first row to header and delete the row
Dalles_chinook_t <- t(Dalles_chinook)
#Transpose
colnames(Dalles_chinook_t) <- Dalles_chinook_t[1,]
Dalles_chinook_t <- Dalles_chinook_t[-1,]
#Move first row to header and delete the row

Dalles_chinook_t <- as.data.frame(Dalles_chinook_t)

Dalles_chinook_t <- Dalles_chinook_t %>% replace(is.na(.), 0)
#make NA into 0 values
Dalles_chinook_t <- Dalles_chinook_t %>% select(1:365)
#Delete extra info we don't want 
str(Dalles_chinook_t)
#Check what kind of data we have... Oh no! It's character data not numeric data
Dalles_chinook_t <-Dalles_chinook_t %>% mutate_all(function(x) as.numeric(as.character(x)))
#Change character to numeric data
Dalles_chinook_sum <- Dalles_chinook_t %>%
  mutate(sum_of_rows = rowSums(Dalles_chinook_t)) 
#Add a new column summing the rows

Dalles_chinook_sum$year <- 2023:1957
#Add a year column with just the year 


Dalles_chinook_sum <- Dalles_chinook_sum %>% mutate(sum_of_rows_100 = (sum_of_rows/1000))
x_min <- min(Dalles_chinook_sum$year)
y_max <- max(Dalles_chinook_sum$sum_of_rows_100)
ggplot(data = Dalles_chinook_sum, aes(x = year, y = sum_of_rows_100)) +
  geom_point() +
  #geom_line(color = "darkgreen") +
  labs(title = "Number of Chinook Crossings per Year at the Dalles 1957-2023",
       x = "Year",
       y = "Number of Chinook Crossings (in 1000s)", 
       theme_classic()) + 
  scale_x_continuous(breaks = seq(x_min,2023,5)) + 
  scale_y_continuous(breaks = seq(0,1100,100))
ggsave(filename="Chinook_Dalles_Graph_noline.jpg",  plot=last_plot(),path="output", width=2500, height=1200, units="px")

#You can comment out the `geom_line()` command to include a connecting line or not