### This code will create a graph of Steelhead crossing the Bonneville Dam from 1939-2023

library(tidyverse)
Bon_steel <- read_csv("Data/Steelhead_1939_2023_BonnevilleDamCSV.csv")

names(Bon_steel) <- Bon_steel[1,]
Bon_steel <- Bon_steel[-1,]
#Move first row to header and delete the row
Bon_steel_t <- t(Bon_steel)
#Transpose
colnames(Bon_steel_t) <- Bon_steel_t[1,]
Bon_steel_t <- Bon_steel_t[-1,]
#Move first row to header and delete the row

Bon_steel_t <- as.data.frame(Bon_steel_t)

Bon_steel_t <- Bon_steel_t %>% replace(is.na(.), 0)
#make NA into 0 values
Bon_steel_t <- Bon_steel_t %>% select(1:365)
#Delete extra info we don't want 
str(Bon_steel_t)
#Check what kind of data we have... Oh no! It's character data not numeric data
Bon_steel_t <-Bon_steel_t %>% mutate_all(function(x) as.numeric(as.character(x)))
#Change character to numeric data
Bon_steel_sum <-  Bon_steel_t %>%
  mutate(sum_of_rows = rowSums(Bon_steel_t)) 
#Add a new column summing the rows
Bon_steel_sum <- Bon_steel_sum[-(22:86),]
 #Delete extra rows that have all NA values


Bon_steel_sum$year <- 2023:2003
#Add a year column with just the year 


Bon_steel_sum <- Bon_steel_sum %>% mutate(sum_of_rows_100 = (sum_of_rows/1000))
x_min <- min(Bon_steel_sum$year)
y_max <- max(Bon_steel_sum$sum_of_rows_100)
ggplot(data = Bon_steel_sum, aes(x = year, y = sum_of_rows_100)) +
  geom_point() +
  geom_line(color = "orange") +
  labs(title = "Number of Steelhead Crossings per Year at Bonneville Dam 2003-2023",
       x = "Year",
       y = "Number of Steelhead Crossings (in 1000s)", 
       color = "darkgreen") +
     scale_x_continuous(breaks = seq(x_min,2023,2))  +
     scale_y_continuous(breaks = seq(0,175,25))
ggsave(filename="Steelhead_Bonneville_Graph_noline.jpg",  plot=last_plot(),path="output", width=2500, height=1200, units="px")

#You can comment out the `geom_line()` command to include a connecting line or not