library(tidyverse)

#pdx_2.5: measure of pm2.5 in Portland everyday from 2000-2023
#la_2.5: measure of pm2.5 in Los Angeles everyday from 2000-2023
pdx_2.5 <- read_csv("Portland_2.5_2000-2023.csv")
la_2.5 <- read_csv("LosAngeles_2.5_2000-2023.csv")

colnames(pdx_2.5)[2] <- 'AQIVal'
colnames(la_2.5)[2] <- 'AQIVal'

pdx_2.5date<- pdx_2.5 %>%
  mutate(Date = mdy(Date)) %>%
  mutate(Year = year(Date),
         Month = month(Date),
         DOY = yday(Date))

la_2.5date<- la_2.5 %>%
  mutate(Date = mdy(Date)) %>%
  mutate(Year = year(Date),
         Month = month(Date),
         DOY = yday(Date)) %>%
  mutate(AQI_Category = case_when(AQIVal >= 250.5 ~ 'Hazardous',
                                  AQIVal >= 150.5 ~ 'Very Unhealthy',
                                  AQIVal >= 55.5 ~ 'Unhealthy',
                                  AQIVal >= 35.5 ~ 'Unhealthy for Sensitive Groups',
                                  AQIVal >= 12.1 ~ 'Moderate',
                                  TRUE ~ 'Good')) %>%
  
  mutate(AQI_Category = factor(AQI_Category, levels= c('Good', 'Moderate', 'Unhealthy',
                                                       'Unhealthy for Sensitive Groups', 'Very Unhealthy', 'Hazardous')))

ggplot(la_2.5date, aes(x = DOY, y = Year, fill = AQI_Category))+
  geom_tile()+
  scale_y_reverse()+
  scale_fill_manual(values = c('#FFFF00', '#FFA500', '#E31A1C', '#8F3F97')) +
  theme_bw()

pdx_2.5date<- pdx_2.5 %>%
  mutate(Date = mdy(Date)) %>%
  mutate(Year = year(Date),
         Month = month(Date),
         DOY = yday(Date)) %>%
  mutate(AQI_Category = case_when(AQIVal >= 250.5 ~ 'Hazardous',
                                  AQIVal >= 150.5 ~ 'Very Unhealthy',
                                  AQIVal >= 55.5 ~ 'Unhealthy',
                                  AQIVal >= 35.5 ~ 'Unhealthy for Sensitive Groups',
                                  AQIVal >= 12.1 ~ 'Moderate',
                                  TRUE ~ 'Good')) %>%
  mutate(AQI_Category = factor(AQI_Category, levels= c('Good', 'Moderate', 'Unhealthy',
                                                       'Unhealthy for Sensitive Groups', 'Very Unhealthy', 'Hazardous')))

ggplot(pdx_2.5date, aes(x = DOY, y = Year, fill = AQI_Category))+
  geom_tile()+
  scale_y_reverse()+
  scale_discrete_manual('fill', values = c('#238B44','#FFFF00', '#FFA500', '#E31A1C',
                                           '#8F3F97', '#861130'))

#orange is the aqi category for a pm2.5 value above 35.4
pdx_orange <- pdx_2.5date %>%
  filter(AQIVal > 35.4)
la_orange <- la_2.5date %>%
  filter(AQIVal > 35.4)

#red is the aqi category for a pm2.5 value above 55.4
pdx_red <- pdx_2.5date %>%
  filter(AQIVal > 55.4)
la_red <- la_2.5date %>%
  filter(AQIVal > 55.4)

#purple is the aqi category for a pm2.5 value above 150.4
pdx_purple <- pdx_2.5date %>%
  filter(AQIVal > 150.4)
la_purple <- la_2.5date %>%
  filter(AQIVal > 150.4)

#violet is the aqi category for a pm2.5 value above 250
pdx_violet <- pdx_2.5date %>%
  filter(AQIVal > 250)
la_violet <- la_2.5date %>%
  filter(AQIVal > 250)

pdx_orangecount_by_year <- pdx_orange %>%
  group_by(Year) %>%
  count()
la_orangecount_by_year <- la_orange %>%
  group_by(Year) %>%
  count()
pdx_redcount_by_year <- pdx_red %>%
  group_by(Year) %>%
  count()
la_redcount_by_year <- la_red %>%
  group_by(Year) %>%
  count()
pdx_purplecount_by_year <- pdx_purple %>%
  group_by(Year) %>%
  count()
la_purplecount_by_year <- la_purple %>%
  group_by(Year) %>%
  count()
pdx_violetcount_by_year <- pdx_violet %>%
  group_by(Year) %>%
  count()
la_violetcount_by_year <- la_violet %>%
  group_by(Year) %>%
  count()

ggplot(data = pdx_redcount_by_year, aes(x = Year, y = n, color = 'red')) +
  geom_point() +
  labs(title = "PM 2.5 Value of >55.4 ug/m3 in Portland, 2000-2023",
       x = "Year",
       y = "PM2.5 (ug/m3)") +
  theme(legend.position= "none")

ggplot(data = pdx_orangecount_by_year, aes(x = Year, y = n)) +
  geom_point(color = 'orange') +
  geom_smooth(method = 'lm', color= 'orange')+
  labs(title = "PM 2.5 Value of >35.4 ug/m3 in Portland, 2000-2023",
       x = "Year",
       y = "PM2.5 (ug/m3)") +
  theme(legend.position= "none")

ggplot(data = la_orangecount_by_year, aes(x = Year, y = n, color = 'orange')) +
  geom_point() +
  geom_smooth(method = 'lm')+
  labs(title = "PM 2.5 Value of >35.4 ug/m3 in Los Angeles, 2000-2023",
       x = "Year",
       y = "PM2.5 (ug/m3)") +
  theme(legend.position= "none")

ggplot(data = la_2.5, aes(x = Date, y = AQIVal)) +
  geom_point() +
  labs(title = "AQI Value in Los Angeles, 2000-2023",
       x = "Date",
       y = "AQI Value") +
  theme_classic()

ggplot(data = pdx_redcount_by_year, aes(x = Year, y = n, color = 'red')) +
  geom_point() +
  labs(title = "PM 2.5 Value of >55.4 ug/m3 in Portland, 2000-2023",
       x = "Year",
       y = "PM2.5 (ug/m3)") +
  theme(legend.position= "none")

ggplot(data = la_redcount_by_year, aes(x = Year, y = n, color = 'red')) +
  geom_point() +
  geom_smooth(method = lm) +
  labs(title = "PM 2.5 Value of >55.4 in Los Angeles, 2000-2023",
       x = "Year",
       y = "PM2.5 (ug/m3)") +
  theme(legend.position="none")

ggplot(data = pdx_redcount_by_year, aes(x = Year, y = n, color = 'red')) +
  geom_point() +
  geom_smooth(method = lm) +
  labs(title = "PM2.5 Value of >55.4 ug/m3 in Portland, 2000-2023",
       x = "Date",
       y = "AQI Value") +
  theme(legend.position="none")

ggplot(data = la_2.5, aes(x = Date, y = AQIVal)) +
  geom_point() +
  labs(title = "AQI Value in Los Angeles, 2000-2023",
       x = "Date",
       y = "AQI Value") +
  theme_classic()

ggplot(data = la_2.5, aes(x = Date, y = AQIVal)) +
  geom_point() +
  labs(title = "AQI Value in Los Angeles, 2000-2023",
       x = "Date",
       y = "AQI Value") +
  theme_classic()
